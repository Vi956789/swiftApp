//
//  AppStoreConnectAPIExampleApp.swift
//  Shared
//
//  Created by Antoine van der Lee on 11/07/2022.
//

import SwiftUI

@main
struct AppStoreConnectAPIExampleApp: App {
    var body: some Scene {
        WindowGroup {
            AppsListView()
        }
    }
}
